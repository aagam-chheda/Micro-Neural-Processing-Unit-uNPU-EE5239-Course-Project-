# lib_prep.tcl -- Stage 0: build the reference library once.
# Run:  icc2_lm_shell -f scripts/lib_prep.tcl > logs/lib_prep.log
# SKIP this if pnr/scl_fs120.ndm already exists from Part 1.
source scripts/00_vars.tcl

create_workspace -flow normal -technology $TF scl_fs120   ;# empty library + 4-metal tech rules
read_db  [list $DB_SS $DB_FF]                             ;# timing of every cell, slow + fast corner
read_lef $STD_LEF                                         ;# shape + pins of every cell
check_workspace                                           ;# do .db and .lef agree, cell by cell?
commit_workspace -output $REF_NDM                         ;# write pnr/scl_fs120.ndm
exit
